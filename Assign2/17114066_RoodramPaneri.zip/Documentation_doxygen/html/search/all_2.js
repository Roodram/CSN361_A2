var searchData=
[
  ['ques1_5fclient_2ec',['Ques1_client.c',['../_ques1__client_8c.html',1,'']]],
  ['ques1_5fserver_2ec',['Ques1_server.c',['../_ques1__server_8c.html',1,'']]],
  ['ques2_5fzombie_5forphan_2ec',['Ques2_zombie_orphan.c',['../_ques2__zombie__orphan_8c.html',1,'']]]
];
