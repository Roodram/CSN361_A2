var searchData=
[
  ['main',['main',['../_ques1__client_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;Ques1_client.c'],['../_ques1__server_8c.html#abf9e6b7e6f15df4b525a2e7705ba3089',1,'main(int argc, char const *argv[]):&#160;Ques1_server.c'],['../_ques2__zombie__orphan_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;Ques2_zombie_orphan.c']]]
];
