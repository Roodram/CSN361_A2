var searchData=
[
  ['port',['PORT',['../_ques1__client_8c.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;Ques1_client.c'],['../_ques1__server_8c.html#a614217d263be1fb1a5f76e2ff7be19a2',1,'PORT():&#160;Ques1_server.c']]]
];
